package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.entity.EntityNull;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Player-proportioned model with the supplied skin, fade in/out, dark aura layer and glowing eyes layer. */
public class RenderNull extends RenderLiving<EntityNull> {
    public static final ResourceLocation SKIN = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null.png");

    // 2nd constructor argument: true = slim (Alex) arms, false = classic (Steve) arms.
    public RenderNull(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, false), 0.0F);
        this.addLayer(new LayerNullAura(this));
        this.addLayer(new LayerNullEyes(this));
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityNull entity) {
        return SKIN;
    }

    @Override
    protected void preRenderCallback(EntityNull entity, float partialTicks) {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.color(1F, 1F, 1F, entity.getAlpha());
    }

    @Override
    public void doRender(EntityNull entity, double x, double y, double z, float entityYaw, float partialTicks) {
        if (entity.getAlpha() <= 0.01F) return;
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.disableBlend();
    }
}
