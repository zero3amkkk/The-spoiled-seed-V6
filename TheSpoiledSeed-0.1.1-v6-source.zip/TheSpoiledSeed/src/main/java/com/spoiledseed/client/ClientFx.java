package com.spoiledseed.client;

import com.spoiledseed.network.PacketFx;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Client-side effect state, written by packets and read by the handlers and screens. */
public class ClientFx {
    public static final int JUMP_LEN = 40;
    public static final int ENDING_LEN = 520;

    public static float fogTarget, fogCurrent;
    public static int jumpTicks, jumpVariant;
    public static int endingTick = -1;
    public static float chaseDist = -1F;       // blocks to The Null while it hunts you, < 0 = no chase
    public static int chaseAge;
    private static boolean joinSynced;
    public static int stage, threat;
    public static float minutes;

    public static void handle(int type, float value, float value2) {
        if (type == PacketFx.FOG) fogTarget = value;
        else if (type == PacketFx.JUMPSCARE) { jumpTicks = JUMP_LEN; jumpVariant = (int) value; }
        else if (type == PacketFx.ENDING) endingTick = 0;
        else if (type == PacketFx.CHASE_DIST) { chaseDist = value; chaseAge = 0; }
        else if (type == PacketFx.OPTIONS) { if (joinSynced) ClientConfig.mask = (int) value; }   // before the join sync our own preference wins
        else if (type == PacketFx.STATS) { stage = ((int) value) & 15; threat = ((int) value) >> 4; minutes = value2; }
    }


    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (Minecraft.getMinecraft().theWorld == null) {       // left the world
            fogTarget = 0F; fogCurrent = 0F; jumpTicks = 0; endingTick = -1; chaseDist = -1F; joinSynced = false;
            return;
        }
        if (!joinSynced && Minecraft.getMinecraft().thePlayer != null && Minecraft.getMinecraft().thePlayer.ticksExisted > 20) {
            joinSynced = true;
            ClientConfig.commit();                                 // apply the options chosen in the menu to this world
        }
        fogCurrent += (fogTarget - fogCurrent) * 0.03F;
        if (Math.abs(fogTarget - fogCurrent) < 0.002F) fogCurrent = fogTarget;
        if (jumpTicks > 0) jumpTicks--;
        if (endingTick >= 0 && ++endingTick > ENDING_LEN) endingTick = -1;
        if (chaseDist >= 0F && ++chaseAge > 30) chaseDist = -1F;     // no update for 1.5 s -> chase is over
    }
}
