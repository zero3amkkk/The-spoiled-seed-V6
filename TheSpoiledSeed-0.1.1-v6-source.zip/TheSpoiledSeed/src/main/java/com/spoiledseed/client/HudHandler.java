package com.spoiledseed.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** While The Null hunts you: distance above the hearts, a closing-in bar, and a dark red vignette that tightens. */
public class HudHandler {
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL || ClientFx.chaseDist < 0F) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.thePlayer.capabilities.isCreativeMode) return;
        ScaledResolution sr = e.getResolution();
        int w = sr.getScaledWidth(), h = sr.getScaledHeight();
        int d = (int) Math.ceil(ClientFx.chaseDist);

        float closeness = 1F - Math.min(1F, ClientFx.chaseDist / 24F);
        int a = (int) (120 * closeness * closeness);
        if (a > 0) {                                                // vignette: four edge strips
            int c = (a << 24) | 0x300000;
            int t = (int) (h * 0.14F * (0.5F + closeness));
            Gui.drawRect(0, 0, w, t, c);
            Gui.drawRect(0, h - t, w, h, c);
            Gui.drawRect(0, t, t, h - t, c);
            Gui.drawRect(w - t, t, w, h - t, c);
        }
        if (!ClientConfig.chaseHud) return;
        int x = w / 2 - 91;                                         // same left edge as the hearts
        int y = h - 62;                                             // just above hearts and armor
        boolean blink = (mc.thePlayer.ticksExisted / 4) % 2 == 0;
        int color = d <= 8 ? (blink ? 0xFF3030 : 0xAA0000) : d <= 20 ? 0xFFA040 : 0xE0E0E0;
        mc.fontRendererObj.drawStringWithShadow("THE NULL  " + d + (d == 1 ? " block" : " blocks"), x, y, color);
        int barW = 81;
        float close = 1F - Math.min(1F, d / 40F);
        Gui.drawRect(x, y + 10, x + barW, y + 13, 0x90000000);
        Gui.drawRect(x, y + 10, x + (int) (barW * close), y + 13, 0xFF000000 | color);
    }
}
