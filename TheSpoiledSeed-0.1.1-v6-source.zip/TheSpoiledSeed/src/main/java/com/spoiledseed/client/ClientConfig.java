package com.spoiledseed.client;

import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketOptions;
import java.io.File;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.config.Configuration;

/** Client-only preferences (config/spoiledseed-client.cfg). Edited from the Mod Options screen. */
public class ClientConfig {
    public static boolean uiSounds = true;
    public static boolean menuMusic = true;
    public static boolean reduceFlash = false;
    public static boolean screenShake = true;
    public static boolean chaseHud = true;
    /** Horror/Fog options (same bits as the server): bit0 fog, 1 jumpscare, 2 theft, 3 signs, 4-5 level, 6 ambient, 8-14 fog strength. */
    public static int mask = 1 | 2 | 4 | 8 | (1 << 4) | 64 | (100 << 8);

    private static Configuration cfg;
    private static final String C = "client";

    public static void load(File dir) {
        cfg = new Configuration(new File(dir, "spoiledseed-client.cfg"));
        read();
    }

    private static void read() {
        uiSounds = cfg.get(C, "uiSounds", true, "Hover and click sounds in the mod's menus.").getBoolean();
        menuMusic = cfg.get(C, "menuMusic", true, "Play the mod's sad title music (replaces the vanilla menu music).").getBoolean();
        reduceFlash = cfg.get(C, "reduceFlash", false, "Accessibility: no white flash, softer jumpscare effects.").getBoolean();
        screenShake = cfg.get(C, "screenShake", true, "Camera shake during jumpscares.").getBoolean();
        chaseHud = cfg.get(C, "chaseHud", true, "Show the distance to The Null above your hearts while it hunts you.").getBoolean();
        mask = cfg.get(C, "horrorMask", mask, "Your Horror/Fog options (edit them in Mod Options instead of by hand).").getInt();
        if (cfg.hasChanged()) cfg.save();
    }

    public static void save() {
        if (cfg == null) return;
        cfg.get(C, "uiSounds", true).set(uiSounds);
        cfg.get(C, "menuMusic", true).set(menuMusic);
        cfg.get(C, "reduceFlash", false).set(reduceFlash);
        cfg.get(C, "screenShake", true).set(screenShake);
        cfg.get(C, "chaseHud", true).set(chaseHud);
        cfg.get(C, "horrorMask", mask).set(mask);
        cfg.save();
    }

    public static boolean bit(int n) { return (mask & (1 << n)) != 0; }
    public static int level() { return (mask >> 4) & 3; }
    public static int fogStrength() { return (mask >> 8) & 127; }
    public static void setBit(int n, boolean on) { mask = on ? (mask | (1 << n)) : (mask & ~(1 << n)); }
    public static void setLevel(int l) { mask = (mask & ~(3 << 4)) | ((l & 3) << 4); }
    public static void setFogStrength(int v) { mask = (mask & ~(127 << 8)) | (Math.max(0, Math.min(100, v)) << 8); }
    public static boolean inWorld() { return Minecraft.getMinecraft().theWorld != null && Minecraft.getMinecraft().thePlayer != null; }

    /** Saves, and tells the server when you are in a world (otherwise it is sent when you join). */
    public static void commit() {
        save();
        if (inWorld() && NetworkHandler.CHANNEL != null) NetworkHandler.CHANNEL.sendToServer(new PacketOptions(mask));
    }
}
