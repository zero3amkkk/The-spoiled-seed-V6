package com.spoiledseed.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;

/** Menu button without a box: gray text, white when the mouse is over it, with hover and click sounds. */
public class FlatButton extends GuiButton {
    private boolean wasHovered;
    public boolean selected;          // draws a marker (used for the active category)

    public FlatButton(int id, int x, int y, int w, int h, String text) {
        super(id, x, y, w, h, text);
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (!this.visible) return;
        this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition
                && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
        if (this.hovered && !this.wasHovered && this.enabled) UiAudio.hover();
        this.wasHovered = this.hovered;

        int bg = this.selected ? 0x80303030 : this.hovered ? 0x70202020 : 0x50080808;
        Gui.drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, bg);
        if (this.selected) Gui.drawRect(this.xPosition, this.yPosition, this.xPosition + 2, this.yPosition + this.height, 0xFFC8C8C8);
        int color = !this.enabled ? 0x555555 : (this.hovered || this.selected) ? 0xFFFFFF : 0x9A9A9A;
        this.drawCenteredString(mc.fontRendererObj, this.displayString, this.xPosition + this.width / 2,
                this.yPosition + (this.height - 8) / 2, color);
    }

    @Override
    public void playPressSound(SoundHandler handler) {
        UiAudio.click();
    }
}
