package com.spoiledseed.registry;

import com.spoiledseed.SpoiledSeed;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

/** Sound events. Files live in assets/spoiledseed/sounds/** and are mapped in sounds.json. */
public class ModSounds {
    public static SoundEvent JUMPSCARE, FOOTSTEP, CHASE_STEP, VANISH, HEARTBEAT, WHISPER, BREATH, KNOCK, SCRAPE,
            TAP, CREAK, STING, DRONE, SEAL, UI_HOVER, UI_CLICK, MUSIC_MENU;

    /** Names accepted by /ss play. */
    public static final String[] PLAYABLE = { "jumpscare", "footstep", "chase", "vanish", "heartbeat", "whisper", "breath",
            "knock", "scrape", "tap", "creak", "sting", "drone", "seal" };

    public static void register() {
        JUMPSCARE = make("null.jumpscare");     // TPS S
        FOOTSTEP = make("null.footstep");
        CHASE_STEP = make("null.chase");
        VANISH = make("null.vanish");
        HEARTBEAT = make("null.heartbeat");
        WHISPER = make("null.whisper");
        BREATH = make("null.breath");
        KNOCK = make("null.knock");
        SCRAPE = make("null.scrape");
        TAP = make("null.tap");
        CREAK = make("null.creak");
        STING = make("null.sting");
        DRONE = make("ambient.drone");
        SEAL = make("seal.activate");
        UI_HOVER = make("ui.hover");
        UI_CLICK = make("ui.click");
        MUSIC_MENU = make("music.menu");
    }

    public static SoundEvent byName(String n) {
        switch (n) {
            case "jumpscare": return JUMPSCARE;
            case "footstep": return FOOTSTEP;
            case "chase": return CHASE_STEP;
            case "vanish": return VANISH;
            case "heartbeat": return HEARTBEAT;
            case "whisper": return WHISPER;
            case "breath": return BREATH;
            case "knock": return KNOCK;
            case "scrape": return SCRAPE;
            case "tap": return TAP;
            case "creak": return CREAK;
            case "sting": return STING;
            case "drone": return DRONE;
            case "seal": return SEAL;
            default: return null;
        }
    }

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(SpoiledSeed.MODID, name);
        SoundEvent s = new SoundEvent(rl);
        s.setRegistryName(rl);
        GameRegistry.register(s);
        return s;
    }
}
