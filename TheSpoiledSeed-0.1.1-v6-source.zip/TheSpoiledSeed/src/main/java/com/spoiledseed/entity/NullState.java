package com.spoiledseed.entity;

public enum NullState {
    OBSERVING, STALKING, DISTURBANCE, JUMPSCARE, CHASE, VANISHING;

    public static NullState byId(int id) {
        NullState[] v = values();
        return id >= 0 && id < v.length ? v[id] : OBSERVING;
    }
}
