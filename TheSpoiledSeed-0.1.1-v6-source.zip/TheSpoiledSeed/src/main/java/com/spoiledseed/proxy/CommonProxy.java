package com.spoiledseed.proxy;

import java.io.File;

public class CommonProxy {
    public void preInit(File configDir) {}
    public void init() {}
    /** Client-only effects; dedicated servers ignore this. */
    public void handlePacket(int type, float value, float value2) {}
}
