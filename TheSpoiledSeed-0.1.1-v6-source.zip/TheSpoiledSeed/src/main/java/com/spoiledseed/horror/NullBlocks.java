package com.spoiledseed.horror;

import com.spoiledseed.registry.ModBlocks;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

/**
 * Black "Null Blocks" built by The Null when you hide up high. They give off the same black halo as the monster
 * (particles are driven from here), can be broken with a pickaxe to keep them, and dissolve after 8 minutes.
 */
public class NullBlocks {
    private static class Rec { WorldServer w; BlockPos pos; int ticks; }
    private static final List<Rec> LIST = new ArrayList<Rec>();
    private static final int LIFETIME = 8 * 60 * 20;

    public static void place(WorldServer w, BlockPos pos) {
        w.setBlockState(pos, ModBlocks.nullBlock.getDefaultState());
        Rec r = new Rec();
        r.w = w; r.pos = pos; r.ticks = LIFETIME;
        LIST.add(r);
        w.playSound(null, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, SoundEvents.BLOCK_STONE_PLACE, SoundCategory.HOSTILE, 1.0F, 0.6F);
        w.spawnParticle(EnumParticleTypes.SMOKE_LARGE, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 10, 0.4D, 0.4D, 0.4D, 0.02D);
    }

    /** Called every server tick; works on 10-tick steps. */
    public static void tick(int counter) {
        if (LIST.isEmpty() || counter % 10 != 0) return;
        for (Iterator<Rec> it = LIST.iterator(); it.hasNext();) {
            Rec r = it.next();
            if (r.w.getBlockState(r.pos).getBlock() != ModBlocks.nullBlock) { it.remove(); continue; }   // broken by the player
            r.ticks -= 10;
            if (r.ticks <= 0) {
                r.w.setBlockToAir(r.pos);
                r.w.spawnParticle(EnumParticleTypes.SMOKE_LARGE, r.pos.getX() + 0.5D, r.pos.getY() + 0.5D, r.pos.getZ() + 0.5D, 12, 0.4D, 0.4D, 0.4D, 0.02D);
                it.remove();
                continue;
            }
            r.w.spawnParticle(EnumParticleTypes.SMOKE_LARGE, r.pos.getX() + 0.5D, r.pos.getY() + 0.6D, r.pos.getZ() + 0.5D, 2, 0.45D, 0.45D, 0.45D, 0.005D);
            r.w.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, r.pos.getX() + 0.5D, r.pos.getY() + 0.5D, r.pos.getZ() + 0.5D, 2, 0.5D, 0.5D, 0.5D, 0.01D);
        }
    }

    public static void clear() { LIST.clear(); }
}
