package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.registry.ModSounds;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.WorldServer;

/**
 * Breaking a torch: 25% a terrifying sound; if it was night, 10 seconds of blackness (blindness - 1.9.4 has no "Darkness"
 * effect) and when the sight returns, The Null is standing there for a heartbeat, then gone.
 */
public class TorchScare {
    private static final Random RAND = new Random();

    public static void onTorchBroken(EntityPlayerMP p) {
        if (QuestData.isSealed(p) || p.dimension != 0) return;
        if (!ModConfig.affectCreative && (p.capabilities.isCreativeMode || p.isSpectator())) return;
        PlayerHorror r = HorrorDirector.rec(p);
        if (r.torchCd > 0 || RAND.nextFloat() >= 0.25F) return;
        r.torchCd = 90;
        trigger(p, HorrorDirector.isNight((WorldServer) p.worldObj));
    }

    public static void trigger(final EntityPlayerMP p, boolean night) {
        SoundEvent[] pool = new SoundEvent[] { ModSounds.WHISPER, ModSounds.BREATH, ModSounds.STING, ModSounds.SCRAPE };
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, pool[RAND.nextInt(pool.length)], SoundCategory.HOSTILE, 1.6F, 0.8F);
        if (!night) return;
        p.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 200, 0, false, false));       // 10 seconds
        Scheduler.schedule(205, new Runnable() {
            @Override public void run() { glimpse(p); }
        });
    }

    /** Appears for about a second, then vanishes. */
    private static void glimpse(EntityPlayerMP p) {
        if (p.isDead) return;
        PlayerHorror r = HorrorDirector.rec(p);
        WorldServer w = (WorldServer) p.worldObj;
        if (HorrorDirector.findNull(w, r) != null) return;
        EntityNull n = SpawnHelper.spawn(p, r, NullState.OBSERVING, 5, 9, 28, false, 0F, true);
        if (n != null) n.setPeekMode(1.5F);
    }
}
