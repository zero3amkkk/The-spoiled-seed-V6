package com.spoiledseed.horror;

import com.spoiledseed.quest.QuestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

/** Everything The Null says: chat lines (always from "Null") and the text on its cursed signs. */
public class NullVoice {
    private static final Random RAND = new Random();

    private static final String[] GENERIC = {
        "I see you, {name}.", "Don't turn around.", "I'm right behind you.", "You can't hide from me.", "Look up.",
        "Why are you still here?", "It's so quiet. Listen.", "I like it when you run.", "Count your torches, {name}.",
        "The fog is mine.", "Every block you place, I remember.", "You took something that was never yours.",
        "Sleep well. I won't.", "This world was never yours.", "I am closer than you think.", "Check behind the door.",
        "Do not look at the eyes.", "I counted your steps.", "You are not alone here.", "Run, {name}. Please run."
    };
    private static final String[] BED = {
        "I know where your bed is.", "I stood beside your bed while you slept.", "Your bed is cold now, {name}. I lay in it.",
        "Sleep. I'll be here when you wake up.", "I know where you sleep.", "Your pillow still remembers me."
    };
    private static final String[] HOME = {
        "I was inside your house.", "Nice walls. They won't hold.", "I touched your chests.", "I know every room of your home.",
        "Check your doors, {name}. All of them.", "You built this for me, didn't you?"
    };
    private static final String[] NIGHT = {
        "Night is when I am strongest.", "The dark is my home, {name}.", "Don't go outside.", "Moonlight can't save you.",
        "I am awake. Are you?"
    };
    private static final String[] UNDER = {
        "The dark down here is mine.", "I heard your pickaxe, {name}.", "Stop digging.", "You are very far from the sky.",
        "I'm in the tunnel behind you."
    };
    private static final String[] RELIC = {
        "You carry what is mine.", "Put it back, {name}.", "I can feel it in your pockets.", "You think a Seal can hold me?",
        "Bring it to me and I'll make it quick."
    };
    private static final String[] OTHER = {
        "{other} is not alone anymore.", "{other} cannot hear me. You can.", "I was standing behind {other} a minute ago.",
        "{other} is next.", "Tell {other} I said hello."
    };

    /** A line that fits the player's situation. */
    public static String line(EntityPlayerMP p) {
        List<String[]> pools = new ArrayList<String[]>();
        pools.add(GENERIC);
        pools.add(GENERIC);
        if (p.getBedLocation() != null) pools.add(BED);
        if (HorrorDirector.isNearHome(p)) { pools.add(HOME); pools.add(HOME); }
        if (HorrorDirector.isNight((net.minecraft.world.WorldServer) p.worldObj)) pools.add(NIGHT);
        if (HorrorDirector.isUnderground(p)) { pools.add(UNDER); pools.add(UNDER); }
        if (QuestData.getThreat(p) >= 6) { pools.add(RELIC); pools.add(RELIC); }
        String other = otherPlayer(p);
        if (other != null) { pools.add(OTHER); pools.add(OTHER); }       // multiplayer: it talks about the others
        String[] pool = pools.get(RAND.nextInt(pools.size()));
        String t = pool[RAND.nextInt(pool.length)];
        return t.replace("{name}", p.getName()).replace("{other}", other == null ? "someone" : other);
    }

    /** Another online player (multiplayer), or null. */
    public static String otherPlayer(EntityPlayerMP p) {
        MinecraftServer s = p.getServer();
        if (s == null) return null;
        List<String> names = new ArrayList<String>();
        for (EntityPlayerMP q : s.getPlayerList().getPlayerList()) if (q != p) names.add(q.getName());
        return names.isEmpty() ? null : names.get(RAND.nextInt(names.size()));
    }

    public static ITextComponent format(String text) {
        return new TextComponentString(TextFormatting.WHITE + "<" + TextFormatting.DARK_RED + "Null" + TextFormatting.WHITE + "> "
                + TextFormatting.GRAY + text);
    }

    public static void say(EntityPlayerMP p, String text) { p.addChatMessage(format(text)); }

    public static void say(EntityPlayerMP p) { say(p, line(p)); }

    /** To everybody online. */
    public static void broadcast(MinecraftServer server, String text) {
        if (server == null) return;
        ITextComponent c = format(text);
        for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) q.addChatMessage(c);
    }

    // ---- signs: 4 lines of at most 15 characters ----
    private static final String[][] SIGNS = {
        { "I KNOW WHERE", "YOUR BED IS", "", "" },
        { "TURN BACK", "NOW", "", "" },
        { "BEHIND YOU", "", "", "" },
        { "YOU CANT HIDE", "FROM ME", "", "" },
        { "I WAS IN", "YOUR HOUSE", "", "" },
        { "STOP", "BUILDING", "", "" },
        { "THE FOG IS", "MINE", "", "" },
        { "DONT LOOK UP", "", "", "" },
        { "LEAVE THIS", "WORLD", "", "" },
        { "I AM NULL", "", "", "" },
        { "I WILL BREAK", "YOUR DOOR", "", "" },
        { "THEY ALL", "LEFT. YOU", "STAYED.", "" },
        { "DO NOT", "BREAK ME", "", "" },
        { "IT HEARD", "YOU DIG", "", "" },
        { "RUN", "", "", "" }
    };

    public static String[] signLines(EntityPlayerMP p) {
        int roll = RAND.nextInt(5);
        if (roll == 0) {                                              // personal sign
            String n = p.getName().toUpperCase();
            if (n.length() > 15) n = n.substring(0, 15);
            return new String[] { n, "I SEE YOU", "", "" };
        }
        if (roll == 1 && HorrorDirector.isUnderground(p)) return new String[] { "THE DARK DOWN", "HERE IS MINE", "", "" };
        if (roll == 2 && QuestData.getThreat(p) >= 6) return new String[] { "PUT IT BACK", "", "", "" };
        return SIGNS[RAND.nextInt(SIGNS.length)];
    }
}
