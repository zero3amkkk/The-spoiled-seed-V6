package com.spoiledseed.horror;

import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.quest.QuestData;
import java.util.Random;
import net.minecraft.block.BlockLog;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

/** Everything about WHERE and HOW The Null enters the world. */
public class SpawnHelper {
    private static final Random RAND = new Random();

    /** Spawn at a scored spot (forest, dark, high, in line of sight). Never in front of the camera. */
    public static EntityNull spawn(EntityPlayerMP p, PlayerHorror r, NullState st, int minD, int maxD,
                                   int life, boolean ritual, float escalate, boolean wantSight) {
        if (QuestData.isSealed(p)) return null;
        WorldServer w = (WorldServer) p.worldObj;
        if (HorrorDirector.findNull(w, r) != null) return null;               // never duplicate
        BlockPos pos = findSpot(w, new BlockPos(p), p, minD, maxD, wantSight);
        if (pos == null) pos = standingSpotAround(w, new BlockPos(p), minD / 2 + 4, minD / 2 + 12, p);
        if (pos == null) return null;
        return spawnAt(p, r, pos, st, life, ritual, escalate);
    }

    public static EntityNull spawnAt(EntityPlayerMP p, PlayerHorror r, BlockPos pos, NullState st, int life, boolean ritual, float escalate) {
        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = new EntityNull(w);
        n.setLocationAndAngles(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, RAND.nextFloat() * 360F, 0F);
        n.init(p, st, life, ritual, escalate);
        w.spawnEntityInWorld(n);
        r.nullId = n.getUniqueID();
        return n;
    }

    /** Final ritual: chase with no timeout, on any standing spot near the player (works underground). */
    public static EntityNull spawnRitualNull(EntityPlayerMP p) {
        PlayerHorror r = HorrorDirector.rec(p);
        WorldServer w = (WorldServer) p.worldObj;
        if (HorrorDirector.findNull(w, r) != null) return null;
        BlockPos pos = standingSpotAround(w, new BlockPos(p), 10, 16, null);
        if (pos == null) pos = standingSpotAround(w, new BlockPos(p), 5, 9, null);
        if (pos == null) pos = standingSpotAround(w, new BlockPos(p), 2, 4, null);
        if (pos == null) return null;
        return spawnAt(p, r, pos, NullState.CHASE, 0, true, 0F);
    }

    public static BlockPos findSpot(WorldServer w, BlockPos c, EntityPlayerMP p, int minD, int maxD, boolean wantSight) {
        BlockPos best = null;
        int bestScore = -999;
        Vec3d look = p.getLookVec();
        double ll = Math.sqrt(look.xCoord * look.xCoord + look.zCoord * look.zCoord);
        Vec3d eye = new Vec3d(p.posX, p.posY + p.getEyeHeight(), p.posZ);
        for (int i = 0; i < 16; i++) {
            double ang = RAND.nextDouble() * Math.PI * 2D;
            double dist = minD + RAND.nextDouble() * Math.max(1, maxD - minD);
            double dx = Math.cos(ang) * dist, dz = Math.sin(ang) * dist;
            if (ll > 0.01D && (dx * look.xCoord + dz * look.zCoord) / (ll * dist) > 0.3D) continue;   // not in the camera cone
            BlockPos probe = new BlockPos(c.getX() + (int) dx, 64, c.getZ() + (int) dz);
            if (!w.isBlockLoaded(probe)) continue;
            BlockPos g = w.getHeight(probe);
            while (g.getY() > 1 && (w.isAirBlock(g.down()) || isFoliage(w.getBlockState(g.down())))) g = g.down();
            if (!w.getBlockState(g.down()).getMaterial().isSolid()) continue;
            if (!w.isAirBlock(g) || !w.isAirBlock(g.up())) continue;
            int score = 0;
            if (w.getLight(g) < 8) score += 2;
            score += trees(w, g);
            if (g.getY() > p.posY + 2) score += 2;
            if (wantSight) {
                boolean visible = w.rayTraceBlocks(eye, new Vec3d(g.getX() + 0.5D, g.getY() + 1.6D, g.getZ() + 0.5D)) == null;
                score += visible ? 4 : -4;        // we want the player to actually be able to see it
            }
            if (score > bestScore) { best = g; bestScore = score; }
        }
        return best;
    }

    /** Any standing spot (2 air blocks over a solid floor) in a ring. 'avoid' = skip spots in front of that player. */
    public static BlockPos standingSpotAround(WorldServer w, BlockPos c, int minD, int maxD, EntityPlayerMP avoid) {
        Vec3d look = avoid != null ? avoid.getLookVec() : null;
        for (int i = 0; i < 30; i++) {
            double ang = RAND.nextDouble() * Math.PI * 2D;
            double dist = minD + RAND.nextDouble() * Math.max(1, maxD - minD);
            double dx = Math.cos(ang) * dist, dz = Math.sin(ang) * dist;
            if (look != null && (dx * look.xCoord + dz * look.zCoord) / dist > 0.5D) continue;
            int x = c.getX() + (int) dx, z = c.getZ() + (int) dz;
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos b = new BlockPos(x, c.getY() + dy, z);
                if (!w.isBlockLoaded(b)) break;
                if (w.isAirBlock(b) && w.isAirBlock(b.up()) && w.getBlockState(b.down()).getMaterial().isSolid()) return b;
            }
        }
        return null;
    }

    private static boolean isFoliage(IBlockState s) {
        Material m = s.getMaterial();
        return m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE;
    }

    private static int trees(WorldServer w, BlockPos g) {
        int n = 0;
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                for (int dy = 0; dy <= 3; dy++)
                    if (w.getBlockState(g.add(dx, dy, dz)).getBlock() instanceof BlockLog) n++;
        return Math.min(n, 4);
    }
}
