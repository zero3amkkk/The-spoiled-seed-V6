package com.spoiledseed.horror;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-tick scheduler used for delayed effects (footsteps, jumpscare delay, aftermath...). */
public class Scheduler {
    private static class Task { int ticks; Runnable r; }
    private static final List<Task> TASKS = new ArrayList<Task>();

    public static void schedule(int ticks, Runnable r) {
        Task t = new Task();
        t.ticks = Math.max(1, ticks);
        t.r = r;
        TASKS.add(t);
    }

    public static void clear() { TASKS.clear(); }

    public static void tick() {
        if (TASKS.isEmpty()) return;
        List<Runnable> due = new ArrayList<Runnable>();
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext();) {
            Task t = it.next();
            if (--t.ticks <= 0) { due.add(t.r); it.remove(); }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (RuntimeException ex) { ex.printStackTrace(); }
        }
    }
}
