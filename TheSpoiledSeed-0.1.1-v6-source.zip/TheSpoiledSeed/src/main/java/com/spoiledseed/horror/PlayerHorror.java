package com.spoiledseed.horror;

import java.util.UUID;

/** Runtime (not saved) horror state of one player. */
public class PlayerHorror {
    public UUID nullId;                 // the monster currently assigned to this player
    public int cooldown = 30;           // seconds until the next event may fire
    public int jumpCd;                  // seconds until the next NATURAL jumpscare
    public int caveCd;                  // seconds until the next cave-run sound
    public float fogPrelude;            // fog that decays (before encounters / after scares)
    public int episodeLeft;             // seconds left in a natural fog episode
    public float episodeLevel;          // strength of that episode
    public float fogForce = -1F;        // >= 0 : fixed fog set by /ss fog
    public float lastFogSent = -1F;
    public HorrorEvent pending;         // event waiting behind a fog prelude
    public int pendingDelay;
    public float adapt;                 // 0..1: how much The Null has learned from your escapes
    public boolean wasSleeping;
    public int torchCd;                 // seconds until the next torch-break scare
    public int signTimer = 240;         // seconds until the next cursed sign appears by itself
    public int sessionSeconds;          // seconds since this login
    public boolean joinMsgSent;         // "Null joined the game" already shown this session
    public int zoneTimer;
}
